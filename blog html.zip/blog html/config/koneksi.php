<?php

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$host = "sql109.infinityfree.com";
$user = "if0_42403863";
$pass = "W7SUxAbNEyXXGCd";
$db   = "if0_42403863_mountain_blog";

$conn = mysqli_connect($host, $user, $pass, $db);

echo "Koneksi berhasil!";